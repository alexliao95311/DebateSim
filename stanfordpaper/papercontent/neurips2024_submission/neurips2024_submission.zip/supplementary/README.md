# Reproduction Package: Chain-of-Thought Evaluation and Drift Analysis for Multi-Agent AI Debate Systems

This package contains all artifacts necessary to reproduce the experimental results from the paper.

